
const clients = new Set();
var express = require('express');
const path = require('path');
var app = express();
app.set('port', 80);
var http = require('http');
var eserver = http.createServer(app);

var WebSocketServer = require('websocket').server;

wsServer = new WebSocketServer({
    httpServer: eserver,
    autoAcceptConnections: false
});

function originIsAllowed(origin) {
  return true;
}



wsServer.on('request', function(request) {
    //console.log(request);
	if (!originIsAllowed(request.origin)) {
      request.reject();
      console.log((new Date()) + ' Connection from origin ' + request.origin + ' rejected.');
      return;
    }
    
    var connection = request.accept('echo-protocol', request.origin);
    console.log((new Date()) + ' Connection accepted.');
    clients.add(connection);

	  connection.on('message', function incoming(message) {
			console.log('received: %s', message);
			const json = JSON.parse(message.utf8Data);
			var mType = json[0];
			var mContent = json[1];
			if(mType === "playerjoin"){
				assignPlayer(mContent);
			}else if(mType === "point"){
				addpoint(mContent);
			}else if(mType === "switchsides"){
				swapPlayerSides();
			}else if(mType === "emosoundpos"){
				emit0('soundpos');
			}else if(mType === "emosoundneg"){
				emit0('soundneg');			
			}else if(mType === "emosoundluck"){
				emit0('soundluck');
			}
		});

		connection.on('close', function() {
			clients.delete(connection);
	  });
});


app.use('/assets', express.static('assets'));  

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

var playerCnt = 0;

var player1 = 
{
	name: "",
	points: 0,
	sets: 0
}

var player2 = 
{
	name: "",
	points: 0,
	sets: 0
}


var game = 
{
	statusTxt : "OCZEKIWANIE NA GRACZY",
	p1 : player1,
	p2 : player2,
	zlaStronaPaletki: false, //false: lewa | true: prawa
	currentSet : 0
}



var wsMessage = {
	method : "",
	argument : ""
}

var wsGameStatusMessage = {
	method : "gamestatus",
	argument : game
}

function resetGame(){
	game.statusTxt = "MECZ ROZPOCZĘTY";
	game.zlaStronaPaletki = false;
	game.p1.points = 0;
    game.p2.points = 0;
	game.p1.sets = 0;
	game.p2.sets = 0;
	game.currentSet = 1;
}

function updateGameStatus(){
	emit1('gamestatus', game);
	console.log('game status updated');
	console.log(game);
}

function toggleActivePlayer(){
	game.zlaStronaPaletki = !game.zlaStronaPaletki;
	//(game.activePlayer == 1) ? game.statusTxt = "MECZ TRWA | SERWUJE " + game.p1name : game.statusTxt = "MECZ TRWA | SERWUJE " + game.p2name;
}

function swapPlayerSides(){
	var tempplayer = game.p1;
	game.p1 = game.p2;
	game.p2 = tempplayer;
	updateGameStatus();
	console.log('sides swap');
	console.log(game);
}

function matchControl(){
	if(game.p1.points <= 20 && game.p2.points <= 20)
	{
		if(((game.p1.points+game.p2.points)%5)==0)
		{
			toggleActivePlayer();
			updateGameStatus();
			setTimeout(function(){emit0('coinsound');},1500);
		}
	}
	else
	{
			toggleActivePlayer();
			updateGameStatus();
			setTimeout(function(){emit0('coinsound');},1500);
	}		
	
	if(game.p1.points >= 21 && game.p1.points - game.p2.points >= 2)
	{
		game.p1.sets++;
		game.p1.points = 0;
		game.p2.points = 0;
		game.currentSet++;
		game.zlaStronaPaletki = false;
		updateGameStatus();
		emit1('globalmessage', game.p1.name + ' wygrał seta');
		emit0('switchsides');
		checkWin();
	}
	else if(game.p2.points >= 21 && game.p2.points - game.p1.points >= 2)
	{
		game.p2.sets++;
		game.p1.points = 0;
		game.p2.points = 0;
		game.currentSet++;
		game.zlaStronaPaletki = false;
		updateGameStatus();
		emit1('globalmessage', game.p2.name + ' wygrał seta');
		emit0('switchsides');
		checkWin();
	}	
}

function checkWin(){
	if(game.p1.sets >= 3 || game.p2.sets >= 3)
	{
		if(game.p1.sets > game.p2.sets)
		{
			resetGame();
			updateGameStatus();
			emit1('globalmessage', game.p1.name + ' WYGRAŁ MECZ!!!');
			emit0('switchsides');
			emit0('winsound');
			return true;
		}
		else
		{
			resetGame();
			updateGameStatus();
			emit1('globalmessage', game.p2.name + ' WYGRAŁ MECZ!!!');
			emit0('switchsides');
			emit0('winsound');
			return true;
		}
	}
	else return false;
}

function assignPlayer(usr){
	chuj: if(usr == 'display'){
		break chuj;
	  }else if(usr !== game.p1.name && usr !== game.p2.name && playerCnt < 2){
		  if(game.p1.name === ""){
			game.p1.name = usr;	
			playerCnt++;
			console.log(usr+' has joined the match and get assignment to slot 1');
		  }else if(game.p2.name === ""){
			game.p2.name = usr;
			playerCnt++;
			console.log(usr+' has joined the match and get assignment to slot 2');
		  }
		  updateGameStatus();	
		  emit1('globalmessage', usr + ' has joined the match!');
		  
	  }else
	  {
		  console.log(usr+ ' joind, but he is already assigned or all slots are in use.');
	  }
	  if(playerCnt == 2){
		  game.currentSet = 1;
		  game.statusTxt = "MECZ TRWA | SERWUJE " + game.p1.name;
		  updateGameStatus();
		  emit1('globalmessage', 'MECZ ZOSTAŁ ROZPOCZĘTY!');
		  emit0('startsound');
		  emit0('initslider');
		  console.log('slider initiated');
	  }
}

function addpoint(plr){
	if(plr === game.p1.name)
	{
		game.p1.points++;
	}else if(plr === game.p2.name)
	{
		game.p2.points++;
	}else if (plr === 'display'){
		resetGame();
		updateGameStatus();
		emit1('globalmessage','!!! MECZ ZOSTAŁ ZRESETOWANY !!!');
		console.log('reset meczu');
		
	}	
	updateGameStatus();
	emit1('globalmessage', plr + ' zdobywa punkt');
	emit1('sound',plr);
	console.log(plr + ' zdobywa punkt');
	matchControl();
}

function emit0(txt){
    wsMessage.method = 'execmethod';
	wsMessage.argument = txt;
					
    for(let client of clients) {
	  client.send(JSON.stringify(wsMessage));
    }
}

function emit1(mess1,mess2){
	wsMessage.method = mess1;
	wsMessage.argument = mess2;
					
    for(let client of clients) {
	  client.send(JSON.stringify(wsMessage));
    }
}


   eserver.listen(80, () => {
     console.log('Socket server running');
   });
