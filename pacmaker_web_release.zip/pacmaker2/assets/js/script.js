var p1points = 0;
var p2points = 0;
var p1sets = 0;
var p2sets = 0;
var currentSet = 0;
var p1name = "GRACZ1";
var p2name = "GRACZ2";
var activePlayer = 0;

function init(){
    currentSet = 1;
    setActivePlayer(1);
	
	var socket = io();
	socket.on("p1userassign", (arg) => {
		p1name = arg;
		syncLabels();
	});
	socket.on("p2userassign", (arg) => {
		p2name = arg;
		syncLabels();
	});
	
	
	socket.on("addpoint", (arg) => {
	  console.log(arg);
	  if(arg === p1name){
		  p1points++;
		  syncLabels();
	  }else if(arg === p2name){
		  p2points++;
		  syncLabels();
	  }
	  matchControl();
	});
	
}

function matchControl(){
	if(!(p1points == 21 || p2points == 21)){  
		if(((p1points%5)==0) && activePlayer == 1){
			setActivePlayer(2);
		}else if (((p2points%5)==0) && activePlayer == 2){
			setActivePlayer(1);
		}
	}if(Math.abs(p1points-p2points) >= 2){
		//koniec seta
		(p1points > p2points) ? p1sets++ : p2sets ++;
		//sprawdz czy koniec meczu
		
	}
}

$( document ).ready(function() {
    init();
});


function setActivePlayer(playerNum){
    if(playerNum == 1){
		activePlayer = 1;
		document.body.style.backgroundImage = "url('assets/tt1.png')";
		}
    else if(playerNum == 2){
		activePlayer = 2;
		document.body.style.backgroundImage = "url('assets/tt2.png')";
    }else{    
		activePlayer = 0;
		document.body.style.backgroundImage = "url('tt0.png')";
    }
}

function syncLabels(){
    document.getElementById("p1points").value = p1points;
    document.getElementById("p2points").value = p2points;
	document.getElementById("p1name").value = p1name;
	document.getElementById("p2name").value = p2name;
}

